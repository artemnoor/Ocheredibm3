-- Supabase SQL schema for Telegram queue bot.
-- Run this file in Supabase Dashboard -> SQL Editor -> New query -> Run.

create extension if not exists pgcrypto;

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint not null unique,
  full_name text not null check (length(trim(full_name)) >= 3),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_states (
  telegram_id bigint primary key,
  state text not null,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(trim(title)) >= 3),
  description text not null default '',
  is_active boolean not null default true,
  created_by bigint,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.queue_entries (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  position integer not null check (position > 0),
  status text not null default 'waiting' check (status in ('waiting', 'called', 'left', 'cancelled')),
  created_at timestamptz not null default now(),
  called_at timestamptz,
  left_at timestamptz
);

create unique index if not exists uq_queue_waiting_user_event
  on public.queue_entries(event_id, user_id)
  where status = 'waiting';

create index if not exists idx_queue_entries_event_status_position
  on public.queue_entries(event_id, status, position, created_at);

create index if not exists idx_events_active_created_at
  on public.events(is_active, created_at desc);

-- RLS can stay enabled because the bot uses SUPABASE_SERVICE_ROLE_KEY on the backend.
alter table public.users enable row level security;
alter table public.user_states enable row level security;
alter table public.events enable row level security;
alter table public.queue_entries enable row level security;

create or replace function public.register_user(p_telegram_id bigint, p_full_name text)
returns table(id uuid, telegram_id bigint, full_name text)
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users(telegram_id, full_name, updated_at)
  values (p_telegram_id, trim(p_full_name), now())
  on conflict (telegram_id)
  do update set full_name = excluded.full_name, updated_at = now();

  return query
  select u.id, u.telegram_id, u.full_name
  from public.users u
  where u.telegram_id = p_telegram_id;
end;
$$;

create or replace function public.get_user_by_telegram_id(p_telegram_id bigint)
returns table(id uuid, telegram_id bigint, full_name text)
language sql
security definer
set search_path = public
as $$
  select u.id, u.telegram_id, u.full_name
  from public.users u
  where u.telegram_id = p_telegram_id;
$$;

create or replace function public.set_user_state(p_telegram_id bigint, p_state text, p_payload jsonb default '{}'::jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.user_states(telegram_id, state, payload, updated_at)
  values (p_telegram_id, p_state, coalesce(p_payload, '{}'::jsonb), now())
  on conflict (telegram_id)
  do update set state = excluded.state, payload = excluded.payload, updated_at = now();
end;
$$;

create or replace function public.get_user_state(p_telegram_id bigint)
returns table(state text, payload jsonb, updated_at timestamptz)
language sql
security definer
set search_path = public
as $$
  select s.state, s.payload, s.updated_at
  from public.user_states s
  where s.telegram_id = p_telegram_id;
$$;

create or replace function public.clear_user_state(p_telegram_id bigint)
returns void
language sql
security definer
set search_path = public
as $$
  delete from public.user_states s where s.telegram_id = p_telegram_id;
$$;

create or replace function public.create_event(p_title text, p_description text default '', p_created_by bigint default null)
returns table(id uuid, title text, description text, is_active boolean, created_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  insert into public.events(title, description, created_by)
  values (trim(p_title), coalesce(p_description, ''), p_created_by)
  returning events.id, events.title, events.description, events.is_active, events.created_at;
end;
$$;

create or replace function public.close_event(p_event_id uuid)
returns table(id uuid, title text, is_active boolean)
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  update public.events e
  set is_active = false, updated_at = now()
  where e.id = p_event_id
  returning e.id, e.title, e.is_active;
end;
$$;

create or replace function public.list_active_events()
returns table(id uuid, title text, description text, created_at timestamptz, waiting_count integer)
language sql
security definer
set search_path = public
as $$
  select
    e.id,
    e.title,
    e.description,
    e.created_at,
    count(qe.id)::integer as waiting_count
  from public.events e
  left join public.queue_entries qe
    on qe.event_id = e.id and qe.status = 'waiting'
  where e.is_active = true
  group by e.id, e.title, e.description, e.created_at
  order by e.created_at desc;
$$;

create or replace function public.join_queue(p_telegram_id bigint, p_event_id uuid)
returns table(event_id uuid, event_title text, "position" integer, total_waiting integer, already_joined boolean)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid;
  v_entry_id uuid;
  v_title text;
  v_position integer;
  v_rank integer;
  v_total integer;
  v_already boolean := false;
begin
  -- Avoid race conditions when multiple people join the same event at once.
  perform pg_advisory_xact_lock(hashtext(p_event_id::text));

  select u.id into v_user_id
  from public.users u
  where u.telegram_id = p_telegram_id;

  if v_user_id is null then
    raise exception 'user_not_registered';
  end if;

  select e.title into v_title
  from public.events e
  where e.id = p_event_id and e.is_active = true;

  if v_title is null then
    raise exception 'event_not_found_or_closed';
  end if;

  select qe.id, qe.position into v_entry_id, v_position
  from public.queue_entries qe
  where qe.event_id = p_event_id
    and qe.user_id = v_user_id
    and qe.status = 'waiting'
  order by qe.created_at desc
  limit 1;

  if v_entry_id is null then
    select coalesce(max(qe.position), 0) + 1 into v_position
    from public.queue_entries qe
    where qe.event_id = p_event_id;

    insert into public.queue_entries(event_id, user_id, position)
    values (p_event_id, v_user_id, v_position)
    returning id into v_entry_id;

    v_already := false;
  else
    v_already := true;
  end if;

  select count(*)::integer into v_total
  from public.queue_entries qe
  where qe.event_id = p_event_id and qe.status = 'waiting';

  select count(*)::integer into v_rank
  from public.queue_entries qe
  where qe.event_id = p_event_id
    and qe.status = 'waiting'
    and qe.position <= v_position;

  return query select p_event_id, v_title, v_rank, v_total, v_already;
end;
$$;

create or replace function public.leave_queue(p_telegram_id bigint, p_event_id uuid)
returns table(event_id uuid, event_title text, left_queue boolean)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid;
  v_title text;
  v_left boolean := false;
begin
  select u.id into v_user_id
  from public.users u
  where u.telegram_id = p_telegram_id;

  select e.title into v_title
  from public.events e
  where e.id = p_event_id;

  if v_title is null then
    raise exception 'event_not_found';
  end if;

  if v_user_id is not null then
    with changed as (
      update public.queue_entries qe
      set status = 'left', left_at = now()
      where qe.event_id = p_event_id
        and qe.user_id = v_user_id
        and qe.status = 'waiting'
      returning qe.id
    )
    select exists(select 1 from changed) into v_left;
  end if;

  return query select p_event_id, v_title, v_left;
end;
$$;

create or replace function public.my_queue(p_telegram_id bigint)
returns table(event_id uuid, event_title text, rank integer, total_waiting integer, joined_at timestamptz)
language sql
security definer
set search_path = public
as $$
  with ranked as (
    select
      qe.event_id,
      e.title as event_title,
      qe.user_id,
      qe.created_at as joined_at,
      row_number() over (partition by qe.event_id order by qe.position, qe.created_at)::integer as rank,
      count(*) over (partition by qe.event_id)::integer as total_waiting
    from public.queue_entries qe
    join public.events e on e.id = qe.event_id
    where qe.status = 'waiting' and e.is_active = true
  )
  select r.event_id, r.event_title, r.rank, r.total_waiting, r.joined_at
  from ranked r
  join public.users u on u.id = r.user_id
  where u.telegram_id = p_telegram_id
  order by r.joined_at desc;
$$;

create or replace function public.event_queue(p_event_id uuid)
returns table(event_id uuid, event_title text, rank integer, full_name text, telegram_id bigint, joined_at timestamptz)
language sql
security definer
set search_path = public
as $$
  select
    qe.event_id,
    e.title as event_title,
    row_number() over (order by qe.position, qe.created_at)::integer as rank,
    u.full_name,
    u.telegram_id,
    qe.created_at as joined_at
  from public.queue_entries qe
  join public.users u on u.id = qe.user_id
  join public.events e on e.id = qe.event_id
  where qe.event_id = p_event_id and qe.status = 'waiting'
  order by qe.position, qe.created_at;
$$;

create or replace function public.call_next(p_event_id uuid)
returns table(event_id uuid, event_title text, telegram_id bigint, full_name text, "position" integer)
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  with next_entry as (
    select
      qe.id,
      qe.event_id,
      qe.position,
      u.telegram_id,
      u.full_name,
      e.title as event_title
    from public.queue_entries qe
    join public.users u on u.id = qe.user_id
    join public.events e on e.id = qe.event_id
    where qe.event_id = p_event_id
      and qe.status = 'waiting'
      and e.is_active = true
    order by qe.position, qe.created_at
    limit 1
    for update of qe skip locked
  ), updated as (
    update public.queue_entries qe
    set status = 'called', called_at = now()
    from next_entry ne
    where qe.id = ne.id
    returning ne.event_id, ne.event_title, ne.telegram_id, ne.full_name, ne.position
  )
  select updated.event_id, updated.event_title, updated.telegram_id, updated.full_name, updated.position
  from updated;
end;
$$;

-- Optional hardening for a backend-only bot project.
-- The service role key can execute these functions. Do not use the anon key in this bot.
revoke all on public.users from anon, authenticated;
revoke all on public.user_states from anon, authenticated;
revoke all on public.events from anon, authenticated;
revoke all on public.queue_entries from anon, authenticated;
grant execute on all functions in schema public to service_role;
