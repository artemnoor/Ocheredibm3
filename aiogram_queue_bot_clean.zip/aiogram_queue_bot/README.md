# Aiogram Queue Bot для мероприятий

Готовый Telegram-бот на **aiogram 3 + FastAPI webhook**, рассчитанный на деплой в **Vercel** и хранение данных в **Supabase Postgres**.

## Что умеет

- `/start` — регистрация пользователя.
- Пользователь при старте указывает ФИО.
- Можно указать ФИО сразу: `/start Иванов Иван Иванович`.
- Для каждого мероприятия создаётся отдельная очередь.
- Пользователь может:
  - выбрать мероприятие;
  - встать в очередь;
  - выйти из очереди;
  - посмотреть свою позицию;
  - посмотреть список очереди.
- Администратор может:
  - создавать мероприятия;
  - смотреть ID мероприятий;
  - вызывать следующего участника;
  - закрывать мероприятие.
- База: Supabase Postgres через RPC-функции.
- Деплой: Vercel Python runtime через FastAPI ASGI-приложение.

## Структура проекта

```text
.
├── api/
│   └── index.py              # FastAPI app для Vercel + Telegram webhook
├── bot/
│   ├── config.py             # env-настройки
│   ├── db.py                 # Supabase REST/RPC клиент
│   ├── handlers.py           # aiogram handlers
│   └── keyboards.py          # inline-клавиатуры
├── scripts/
│   ├── set_webhook.py        # установка Telegram webhook
│   ├── delete_webhook.py     # удаление webhook
│   └── get_me.py             # проверка токена бота
├── sql/
│   └── schema.sql            # таблицы, индексы, RPC-функции Supabase
├── .env.example
├── requirements.txt
├── vercel.json
└── README.md
```

## 1. Создай Telegram-бота

1. Открой `@BotFather`.
2. Создай бота через `/newbot`.
3. Сохрани токен в `BOT_TOKEN`.

## 2. Создай Supabase-проект

1. Создай проект в Supabase.
2. Открой **SQL Editor**.
3. Скопируй содержимое `sql/schema.sql`.
4. Выполни SQL.
5. Перейди в **Project Settings → API**.
6. Скопируй:
   - `Project URL` → `SUPABASE_URL`;
   - `service_role key` → `SUPABASE_SERVICE_ROLE_KEY`.

Важно: `SUPABASE_SERVICE_ROLE_KEY` нельзя класть во frontend или публиковать в GitHub. Он должен быть только в переменных окружения Vercel.

## 3. Настрой переменные окружения

Скопируй пример:

```bash
cp .env.example .env
```

Заполни:

```env
BOT_TOKEN=123456789:AA-example-token
WEBHOOK_SECRET=long-random-secret-string
PUBLIC_BASE_URL=https://your-project.vercel.app
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
ADMIN_IDS=123456789
APP_NAME=Queue Bot
```

`ADMIN_IDS` — это Telegram numeric ID администраторов через запятую. Узнать свой ID можно через `@userinfobot`.

## 4. Локальная проверка

Установи зависимости:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

На Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Проверить токен:

```bash
python scripts/get_me.py
```

Локально FastAPI можно поднять так:

```bash
uvicorn api.index:app --reload
```

Но для Telegram в production нужен публичный HTTPS webhook, поэтому основной сценарий — деплой на Vercel.

## 5. Деплой на Vercel

Вариант через Vercel CLI:

```bash
npm i -g vercel
vercel login
vercel
```

Затем в Vercel Dashboard добавь Environment Variables:

```text
BOT_TOKEN
WEBHOOK_SECRET
PUBLIC_BASE_URL
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
ADMIN_IDS
APP_NAME
```

После добавления env-переменных сделай redeploy.

## 6. Установи Telegram webhook

После деплоя и заполнения `PUBLIC_BASE_URL` выполни локально:

```bash
python scripts/set_webhook.py
```

Скрипт установит webhook вида:

```text
https://your-project.vercel.app/api/webhook/YOUR_WEBHOOK_SECRET
```

Удалить webhook можно так:

```bash
python scripts/delete_webhook.py
```

## 7. Как пользоваться ботом

### Пользователь

```text
/start
```

Бот попросит ФИО. Можно сразу:

```text
/start Иванов Иван Иванович
```

Дальше пользователь выбирает мероприятие и встаёт в очередь.

### Администратор

Создать мероприятие:

```text
/new_event Защита проектов | Очередь на демонстрацию проектов
```

Описание необязательно:

```text
/new_event Собеседование
```

Показать ID мероприятий:

```text
/event_ids
```

Вызов следующего участника делается кнопкой в карточке мероприятия.

## 8. Важные замечания

- Для Vercel используется webhook, а не polling.
- У каждого мероприятия отдельная очередь.
- Если пользователь уже стоит в очереди на мероприятие, повторное нажатие не создаст дубль.
- При вызове следующего участника его запись получает статус `called` и пропадает из очереди ожидания.
- При выходе из очереди запись получает статус `left`.
- Очередь сортируется по фактическому порядку входа: `position`, затем `created_at`.
