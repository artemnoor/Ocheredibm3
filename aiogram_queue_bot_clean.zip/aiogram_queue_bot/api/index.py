from __future__ import annotations

from contextlib import asynccontextmanager

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import Update
from fastapi import FastAPI, HTTPException, Request

from bot.config import get_settings
from bot.handlers import router

settings = get_settings()

bot = Bot(
    token=settings.bot_token,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML),
)
dp = Dispatcher()
dp.include_router(router)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Telegram webhook is configured manually by scripts/set_webhook.py after deployment.
    yield


app = FastAPI(title=settings.app_name, lifespan=lifespan)


@app.get("/")
async def health() -> dict[str, str]:
    return {
        "status": "ok",
        "app": settings.app_name,
        "webhook_path": settings.webhook_path,
    }


@app.get("/api/health")
async def api_health() -> dict[str, str]:
    return await health()


@app.post("/api/webhook/{secret}")
async def telegram_webhook(secret: str, request: Request) -> dict[str, bool]:
    if secret != settings.webhook_secret:
        raise HTTPException(status_code=403, detail="Invalid webhook secret")

    data = await request.json()
    update = Update.model_validate(data, context={"bot": bot})
    await dp.feed_update(bot, update)
    return {"ok": True}
