from __future__ import annotations

import asyncio
import os
import sys

import httpx
from dotenv import load_dotenv


async def main() -> int:
    load_dotenv()
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        print("Missing BOT_TOKEN", file=sys.stderr)
        return 1

    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(f"https://api.telegram.org/bot{token}/getMe")
        print(response.text)
        response.raise_for_status()
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
