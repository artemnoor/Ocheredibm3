from __future__ import annotations

import asyncio
import os
import sys

import httpx
from dotenv import load_dotenv


async def main() -> int:
    load_dotenv()
    token = os.getenv("BOT_TOKEN", "").strip()
    secret = os.getenv("WEBHOOK_SECRET", "").strip()
    public_base_url = os.getenv("PUBLIC_BASE_URL", "").strip().rstrip("/")

    if not token or not secret or not public_base_url:
        print("Missing BOT_TOKEN, WEBHOOK_SECRET or PUBLIC_BASE_URL", file=sys.stderr)
        return 1

    webhook_url = f"{public_base_url}/api/webhook/{secret}"
    api_url = f"https://api.telegram.org/bot{token}/setWebhook"

    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(api_url, json={"url": webhook_url, "drop_pending_updates": True})
        print(response.text)
        response.raise_for_status()

    print(f"Webhook set to: {webhook_url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
