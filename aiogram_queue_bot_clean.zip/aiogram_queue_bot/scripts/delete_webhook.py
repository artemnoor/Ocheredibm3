from __future__ import annotations

import asyncio
import os
import sys

import httpx
from dotenv import load_dotenv


async def main() -> int:
    load_dotenv()
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        print("Missing BOT_TOKEN", file=sys.stderr)
        return 1

    api_url = f"https://api.telegram.org/bot{token}/deleteWebhook"
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(api_url, json={"drop_pending_updates": True})
        print(response.text)
        response.raise_for_status()

    print("Webhook deleted")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
