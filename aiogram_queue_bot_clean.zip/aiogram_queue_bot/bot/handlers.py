from __future__ import annotations

import html
from typing import Any

from aiogram import F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, Message

from bot.config import get_settings
from bot.db import DatabaseError, get_db
from bot.keyboards import admin_panel, event_actions, events_keyboard, main_menu

router = Router()


def is_admin(user_id: int | None) -> bool:
    if user_id is None:
        return False
    return user_id in get_settings().admin_ids


def escape(text: Any) -> str:
    return html.escape(str(text or ""))


def valid_full_name(text: str) -> bool:
    parts = [part for part in text.strip().split() if part]
    return len(parts) >= 2 and len(text.strip()) <= 120 and not text.strip().startswith("/")


async def ensure_registered(message: Message) -> bool:
    db = get_db()
    user = await db.get_user(message.from_user.id)
    if user:
        return True
    await db.set_state(message.from_user.id, "awaiting_full_name")
    await message.answer(
        "Сначала укажи ФИО.\n\n"
        "Например: <b>Иванов Иван Иванович</b>",
        parse_mode="HTML",
    )
    return False


async def show_main_menu(message_or_call: Message | CallbackQuery) -> None:
    user_id = message_or_call.from_user.id
    text = (
        "Главное меню очередей.\n\n"
        "Здесь можно выбрать мероприятие, встать в очередь, выйти из неё и посмотреть свою позицию."
    )
    markup = main_menu(is_admin(user_id))
    if isinstance(message_or_call, CallbackQuery):
        await message_or_call.message.edit_text(text, reply_markup=markup)
        await message_or_call.answer()
    else:
        await message_or_call.answer(text, reply_markup=markup)


@router.message(CommandStart())
async def cmd_start(message: Message, command: CommandObject) -> None:
    db = get_db()
    args = (command.args or "").strip()

    if args:
        if not valid_full_name(args):
            await message.answer("ФИО должно состоять минимум из имени и фамилии. Пример: <b>Иванов Иван</b>", parse_mode="HTML")
            return
        user = await db.register_user(message.from_user.id, args)
        await db.clear_state(message.from_user.id)
        await message.answer(
            f"Готово, записал ФИО: <b>{escape(user['full_name'])}</b>",
            parse_mode="HTML",
        )
        await show_main_menu(message)
        return

    user = await db.get_user(message.from_user.id)
    if user:
        await message.answer(f"Ты уже зарегистрирован как <b>{escape(user['full_name'])}</b>.", parse_mode="HTML")
        await show_main_menu(message)
        return

    await db.set_state(message.from_user.id, "awaiting_full_name")
    await message.answer(
        "Привет! Для очередей нужно сначала указать ФИО.\n\n"
        "Отправь ФИО одним сообщением.\n"
        "Например: <b>Иванов Иван Иванович</b>",
        parse_mode="HTML",
    )


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    admin_part = ""
    if is_admin(message.from_user.id):
        admin_part = (
            "\n\n<b>Админ-команды:</b>\n"
            "/new_event Название | описание — создать мероприятие\n"
            "/event_ids — показать ID мероприятий\n"
            "Также в карточке мероприятия есть кнопка вызова следующего участника."
        )
    await message.answer(
        "<b>Команды:</b>\n"
        "/start — регистрация или меню\n"
        "/start Иванов Иван — быстрая регистрация с ФИО\n"
        "/rename Иванов Иван — поменять ФИО\n"
        "/events — список мероприятий\n"
        "/my — мои текущие очереди\n"
        "/help — помощь"
        f"{admin_part}",
        parse_mode="HTML",
    )


@router.message(Command("rename"))
async def cmd_rename(message: Message, command: CommandObject) -> None:
    db = get_db()
    new_name = (command.args or "").strip()
    if not new_name:
        await db.set_state(message.from_user.id, "awaiting_full_name")
        await message.answer("Отправь новое ФИО одним сообщением.")
        return
    if not valid_full_name(new_name):
        await message.answer("ФИО должно состоять минимум из имени и фамилии.")
        return
    user = await db.register_user(message.from_user.id, new_name)
    await db.clear_state(message.from_user.id)
    await message.answer(f"ФИО обновлено: <b>{escape(user['full_name'])}</b>", parse_mode="HTML")


@router.message(Command("events"))
async def cmd_events(message: Message) -> None:
    if not await ensure_registered(message):
        return
    await send_events(message)


@router.message(Command("my"))
async def cmd_my(message: Message) -> None:
    if not await ensure_registered(message):
        return
    await send_my_queue(message)


@router.message(Command("new_event"))
async def cmd_new_event(message: Message, command: CommandObject) -> None:
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администратору.")
        return
    raw = (command.args or "").strip()
    if not raw:
        await message.answer(
            "Формат:\n"
            "<code>/new_event Название мероприятия | Короткое описание</code>\n\n"
            "Описание можно не указывать."
            ,
            parse_mode="HTML",
        )
        return
    if "|" in raw:
        title, description = [part.strip() for part in raw.split("|", 1)]
    else:
        title, description = raw, ""
    if len(title) < 3:
        await message.answer("Название мероприятия слишком короткое.")
        return
    event = await get_db().create_event(title=title, description=description, created_by=message.from_user.id)
    await message.answer(
        "Мероприятие создано.\n\n"
        f"<b>{escape(event['title'])}</b>\n"
        f"ID: <code>{escape(event['id'])}</code>",
        parse_mode="HTML",
        reply_markup=event_actions(event["id"], is_admin=True),
    )


@router.message(Command("event_ids"))
async def cmd_event_ids(message: Message) -> None:
    if not is_admin(message.from_user.id):
        await message.answer("Эта команда доступна только администратору.")
        return
    events = await get_db().list_events()
    if not events:
        await message.answer("Активных мероприятий пока нет.")
        return
    lines = ["<b>Активные мероприятия:</b>"]
    for event in events:
        lines.append(f"• <b>{escape(event['title'])}</b> — <code>{escape(event['id'])}</code>")
    await message.answer("\n".join(lines), parse_mode="HTML")


@router.callback_query(F.data == "menu:main")
async def cb_main_menu(call: CallbackQuery) -> None:
    await show_main_menu(call)


@router.callback_query(F.data == "events:list")
async def cb_events(call: CallbackQuery) -> None:
    if not await ensure_registered_from_callback(call):
        return
    await send_events(call)


@router.callback_query(F.data == "my:queue")
async def cb_my_queue(call: CallbackQuery) -> None:
    if not await ensure_registered_from_callback(call):
        return
    await send_my_queue(call)


@router.callback_query(F.data == "admin:panel")
async def cb_admin_panel(call: CallbackQuery) -> None:
    if not is_admin(call.from_user.id):
        await call.answer("Недоступно", show_alert=True)
        return
    await call.message.edit_text(
        "<b>Админ-панель</b>\n\n"
        "Создавай мероприятия командой /new_event, а затем управляй очередью из карточки мероприятия.",
        parse_mode="HTML",
        reply_markup=admin_panel(),
    )
    await call.answer()


@router.callback_query(F.data == "admin:create_help")
async def cb_admin_create_help(call: CallbackQuery) -> None:
    if not is_admin(call.from_user.id):
        await call.answer("Недоступно", show_alert=True)
        return
    await call.message.edit_text(
        "<b>Создание мероприятия</b>\n\n"
        "Отправь команду:\n"
        "<code>/new_event Защита проектов | Очередь на демонстрацию проектов</code>\n\n"
        "После создания у мероприятия будет отдельная очередь.",
        parse_mode="HTML",
        reply_markup=admin_panel(),
    )
    await call.answer()


@router.callback_query(F.data.startswith("event:"))
async def cb_event(call: CallbackQuery) -> None:
    if not await ensure_registered_from_callback(call):
        return
    event_id = call.data.split(":", 1)[1]
    events = await get_db().list_events()
    event = next((item for item in events if item["id"] == event_id), None)
    if not event:
        await call.answer("Мероприятие не найдено или закрыто", show_alert=True)
        return
    description = event.get("description") or "Описание не указано."
    total = event.get("waiting_count", 0)
    await call.message.edit_text(
        f"<b>{escape(event['title'])}</b>\n\n"
        f"{escape(description)}\n\n"
        f"Сейчас в очереди: <b>{total}</b>",
        parse_mode="HTML",
        reply_markup=event_actions(event_id, is_admin(call.from_user.id)),
    )
    await call.answer()


@router.callback_query(F.data.startswith("join:"))
async def cb_join(call: CallbackQuery) -> None:
    if not await ensure_registered_from_callback(call):
        return
    event_id = call.data.split(":", 1)[1]
    result = await get_db().join_queue(call.from_user.id, event_id)
    already = result.get("already_joined")
    prefix = "Ты уже в очереди." if already else "Готово, ты в очереди."
    await call.message.edit_text(
        f"{prefix}\n\n"
        f"Мероприятие: <b>{escape(result['event_title'])}</b>\n"
        f"Твоя позиция: <b>{result['position']}</b>\n"
        f"Всего ожидают: <b>{result['total_waiting']}</b>",
        parse_mode="HTML",
        reply_markup=event_actions(event_id, is_admin(call.from_user.id)),
    )
    await call.answer("Очередь обновлена")


@router.callback_query(F.data.startswith("leave:"))
async def cb_leave(call: CallbackQuery) -> None:
    if not await ensure_registered_from_callback(call):
        return
    event_id = call.data.split(":", 1)[1]
    result = await get_db().leave_queue(call.from_user.id, event_id)
    if result.get("left_queue"):
        text = f"Ты вышел из очереди на мероприятие <b>{escape(result['event_title'])}</b>."
    else:
        text = f"Ты не стоишь в очереди на мероприятие <b>{escape(result['event_title'])}</b>."
    await call.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=event_actions(event_id, is_admin(call.from_user.id)),
    )
    await call.answer()


@router.callback_query(F.data.startswith("queue:"))
async def cb_queue(call: CallbackQuery) -> None:
    if not await ensure_registered_from_callback(call):
        return
    event_id = call.data.split(":", 1)[1]
    rows = await get_db().event_queue(event_id)
    if not rows:
        await call.message.edit_text("В этой очереди пока никого нет.", reply_markup=event_actions(event_id, is_admin(call.from_user.id)))
        await call.answer()
        return
    title = rows[0].get("event_title", "Мероприятие")
    lines = [f"<b>Очередь: {escape(title)}</b>", ""]
    for row in rows[:40]:
        mark = "👤" if row.get("telegram_id") == call.from_user.id else "•"
        lines.append(f"{mark} <b>{row['rank']}</b>. {escape(row['full_name'])}")
    if len(rows) > 40:
        lines.append(f"\nПоказаны первые 40 из {len(rows)}.")
    await call.message.edit_text(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=event_actions(event_id, is_admin(call.from_user.id)),
    )
    await call.answer()


@router.callback_query(F.data.startswith("next:"))
async def cb_next(call: CallbackQuery) -> None:
    if not is_admin(call.from_user.id):
        await call.answer("Недоступно", show_alert=True)
        return
    event_id = call.data.split(":", 1)[1]
    result = await get_db().call_next(event_id)
    if not result:
        await call.message.edit_text("В очереди никого нет.", reply_markup=event_actions(event_id, is_admin=True))
        await call.answer()
        return

    notify_text = (
        f"Подошла твоя очередь на мероприятие <b>{escape(result['event_title'])}</b>.\n\n"
        "Подойди к организатору."
    )
    try:
        await call.bot.send_message(result["telegram_id"], notify_text, parse_mode="HTML")
        notified = "Участнику отправлено уведомление."
    except Exception:
        notified = "Не удалось отправить уведомление участнику, но в базе он отмечен как вызванный."

    await call.message.edit_text(
        "Следующий участник вызван.\n\n"
        f"<b>{escape(result['full_name'])}</b>\n"
        f"Мероприятие: <b>{escape(result['event_title'])}</b>\n\n"
        f"{notified}",
        parse_mode="HTML",
        reply_markup=event_actions(event_id, is_admin=True),
    )
    await call.answer("Следующий вызван")


@router.callback_query(F.data.startswith("close:"))
async def cb_close_event(call: CallbackQuery) -> None:
    if not is_admin(call.from_user.id):
        await call.answer("Недоступно", show_alert=True)
        return
    event_id = call.data.split(":", 1)[1]
    event = await get_db().close_event(event_id)
    await call.message.edit_text(
        f"Мероприятие закрыто: <b>{escape(event['title'])}</b>",
        parse_mode="HTML",
        reply_markup=main_menu(is_admin=True),
    )
    await call.answer("Мероприятие закрыто")


async def ensure_registered_from_callback(call: CallbackQuery) -> bool:
    db = get_db()
    user = await db.get_user(call.from_user.id)
    if user:
        return True
    await db.set_state(call.from_user.id, "awaiting_full_name")
    await call.message.answer(
        "Сначала укажи ФИО.\n\n"
        "Отправь ФИО одним сообщением. Например: <b>Иванов Иван Иванович</b>",
        parse_mode="HTML",
    )
    await call.answer("Нужно указать ФИО", show_alert=True)
    return False


async def send_events(target: Message | CallbackQuery) -> None:
    events = await get_db().list_events()
    if not events:
        text = "Активных мероприятий пока нет."
        markup = main_menu(is_admin(target.from_user.id))
    else:
        text = "Выбери мероприятие. У каждого мероприятия своя очередь."
        markup = events_keyboard(events)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, reply_markup=markup)
        await target.answer()
    else:
        await target.answer(text, reply_markup=markup)


async def send_my_queue(target: Message | CallbackQuery) -> None:
    rows = await get_db().my_queue(target.from_user.id)
    if not rows:
        text = "Ты сейчас не стоишь ни в одной очереди."
    else:
        lines = ["<b>Твои очереди:</b>", ""]
        for row in rows:
            lines.append(
                f"• <b>{escape(row['event_title'])}</b> — позиция <b>{row['rank']}</b> из <b>{row['total_waiting']}</b>"
            )
        text = "\n".join(lines)
    if isinstance(target, CallbackQuery):
        await target.message.edit_text(text, parse_mode="HTML", reply_markup=main_menu(is_admin(target.from_user.id)))
        await target.answer()
    else:
        await target.answer(text, parse_mode="HTML", reply_markup=main_menu(is_admin(target.from_user.id)))


@router.message(F.text)
async def plain_text(message: Message) -> None:
    db = get_db()
    state = await db.get_state(message.from_user.id)
    if state and state.get("state") == "awaiting_full_name":
        full_name = message.text.strip()
        if not valid_full_name(full_name):
            await message.answer(
                "Похоже, это не ФИО. Отправь минимум имя и фамилию.\n"
                "Например: <b>Иванов Иван</b>",
                parse_mode="HTML",
            )
            return
        user = await db.register_user(message.from_user.id, full_name)
        await db.clear_state(message.from_user.id)
        await message.answer(f"Готово, записал ФИО: <b>{escape(user['full_name'])}</b>", parse_mode="HTML")
        await show_main_menu(message)
        return

    await message.answer(
        "Я не понял сообщение. Открой меню командой /start или посмотри помощь /help.",
        reply_markup=main_menu(is_admin(message.from_user.id)),
    )


@router.errors()
async def errors_handler(event: Any) -> None:
    exception = getattr(event, "exception", None)
    update = getattr(event, "update", None)
    if isinstance(exception, DatabaseError):
        text = "Ошибка базы данных. Проверь SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY и выполнение sql/schema.sql."
    else:
        text = "Произошла ошибка. Попробуй ещё раз или обратись к администратору."

    message = None
    if update:
        message = getattr(update, "message", None) or getattr(update, "callback_query", None)
    try:
        if message and getattr(message, "answer", None):
            await message.answer(text)
    except Exception:
        pass
