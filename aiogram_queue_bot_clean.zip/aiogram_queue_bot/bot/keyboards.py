from __future__ import annotations

from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu(is_admin: bool = False) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="📋 Мероприятия", callback_data="events:list")
    kb.button(text="🙋 Моя очередь", callback_data="my:queue")
    if is_admin:
        kb.button(text="🛠 Админ-панель", callback_data="admin:panel")
    kb.adjust(1)
    return kb.as_markup()


def events_keyboard(events: list[dict]) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for event in events:
        title = event.get("title", "Мероприятие")
        if len(title) > 45:
            title = title[:42] + "..."
        kb.button(text=f"🎫 {title}", callback_data=f"event:{event['id']}")
    kb.button(text="⬅️ В меню", callback_data="menu:main")
    kb.adjust(1)
    return kb.as_markup()


def event_actions(event_id: str, is_admin: bool = False) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Встать в очередь", callback_data=f"join:{event_id}")
    kb.button(text="🚪 Выйти из очереди", callback_data=f"leave:{event_id}")
    kb.button(text="👀 Посмотреть очередь", callback_data=f"queue:{event_id}")
    if is_admin:
        kb.button(text="➡️ Вызвать следующего", callback_data=f"next:{event_id}")
        kb.button(text="🔒 Закрыть мероприятие", callback_data=f"close:{event_id}")
    kb.button(text="⬅️ К мероприятиям", callback_data="events:list")
    kb.adjust(1)
    return kb.as_markup()


def admin_panel() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="📋 Список мероприятий", callback_data="events:list")
    kb.button(text="➕ Как создать мероприятие", callback_data="admin:create_help")
    kb.button(text="⬅️ В меню", callback_data="menu:main")
    kb.adjust(1)
    return kb.as_markup()
