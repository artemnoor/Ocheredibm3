from __future__ import annotations

from typing import Any

import httpx

from bot.config import get_settings


class DatabaseError(RuntimeError):
    pass


class SupabaseDB:
    """Small async wrapper over Supabase PostgREST/RPC API.

    The bot uses Supabase service role key on the backend side only.
    Do not expose SUPABASE_SERVICE_ROLE_KEY in frontend code.
    """

    def __init__(self) -> None:
        settings = get_settings()
        self.base_url = settings.supabase_url
        self.headers = {
            "apikey": settings.supabase_key,
            "Authorization": f"Bearer {settings.supabase_key}",
            "Content-Type": "application/json",
        }
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(20.0, connect=10.0))

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self.base_url}{path}"
        headers = {**self.headers, **kwargs.pop("headers", {})}
        response = await self.client.request(method, url, headers=headers, **kwargs)
        if response.status_code >= 400:
            raise DatabaseError(f"Supabase error {response.status_code}: {response.text}")
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    async def rpc(self, name: str, payload: dict[str, Any] | None = None) -> Any:
        return await self._request("POST", f"/rest/v1/rpc/{name}", json=payload or {})

    async def register_user(self, telegram_id: int, full_name: str) -> dict[str, Any]:
        rows = await self.rpc("register_user", {"p_telegram_id": telegram_id, "p_full_name": full_name})
        return rows[0] if isinstance(rows, list) and rows else rows

    async def get_user(self, telegram_id: int) -> dict[str, Any] | None:
        rows = await self.rpc("get_user_by_telegram_id", {"p_telegram_id": telegram_id})
        return rows[0] if isinstance(rows, list) and rows else None

    async def set_state(self, telegram_id: int, state: str, payload: dict[str, Any] | None = None) -> None:
        await self.rpc("set_user_state", {"p_telegram_id": telegram_id, "p_state": state, "p_payload": payload or {}})

    async def get_state(self, telegram_id: int) -> dict[str, Any] | None:
        rows = await self.rpc("get_user_state", {"p_telegram_id": telegram_id})
        return rows[0] if isinstance(rows, list) and rows else None

    async def clear_state(self, telegram_id: int) -> None:
        await self.rpc("clear_user_state", {"p_telegram_id": telegram_id})

    async def list_events(self) -> list[dict[str, Any]]:
        rows = await self.rpc("list_active_events", {})
        return rows or []

    async def create_event(self, title: str, description: str, created_by: int | None) -> dict[str, Any]:
        rows = await self.rpc(
            "create_event",
            {"p_title": title, "p_description": description, "p_created_by": created_by},
        )
        return rows[0] if isinstance(rows, list) and rows else rows

    async def close_event(self, event_id: str) -> dict[str, Any]:
        rows = await self.rpc("close_event", {"p_event_id": event_id})
        return rows[0] if isinstance(rows, list) and rows else rows

    async def join_queue(self, telegram_id: int, event_id: str) -> dict[str, Any]:
        rows = await self.rpc("join_queue", {"p_telegram_id": telegram_id, "p_event_id": event_id})
        return rows[0] if isinstance(rows, list) and rows else rows

    async def leave_queue(self, telegram_id: int, event_id: str) -> dict[str, Any]:
        rows = await self.rpc("leave_queue", {"p_telegram_id": telegram_id, "p_event_id": event_id})
        return rows[0] if isinstance(rows, list) and rows else rows

    async def my_queue(self, telegram_id: int) -> list[dict[str, Any]]:
        rows = await self.rpc("my_queue", {"p_telegram_id": telegram_id})
        return rows or []

    async def event_queue(self, event_id: str) -> list[dict[str, Any]]:
        rows = await self.rpc("event_queue", {"p_event_id": event_id})
        return rows or []

    async def call_next(self, event_id: str) -> dict[str, Any] | None:
        rows = await self.rpc("call_next", {"p_event_id": event_id})
        return rows[0] if isinstance(rows, list) and rows else None


_db: SupabaseDB | None = None


def get_db() -> SupabaseDB:
    global _db
    if _db is None:
        _db = SupabaseDB()
    return _db
