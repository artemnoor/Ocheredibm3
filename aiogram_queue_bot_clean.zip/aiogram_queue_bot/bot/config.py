from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _optional(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _parse_admin_ids(raw: str) -> set[int]:
    if not raw:
        return set()
    result: set[int] = set()
    for item in raw.replace(";", ",").split(","):
        item = item.strip()
        if not item:
            continue
        try:
            result.add(int(item))
        except ValueError:
            raise RuntimeError(f"ADMIN_IDS must contain Telegram numeric IDs only, got: {item!r}")
    return result


@dataclass(frozen=True)
class Settings:
    bot_token: str
    webhook_secret: str
    supabase_url: str
    supabase_key: str
    admin_ids: set[int]
    public_base_url: str
    app_name: str = "Queue Bot"

    @property
    def webhook_path(self) -> str:
        return f"/api/webhook/{self.webhook_secret}"

    @property
    def webhook_url(self) -> str:
        if not self.public_base_url:
            return ""
        return self.public_base_url.rstrip("/") + self.webhook_path


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings(
        bot_token=_required("BOT_TOKEN"),
        webhook_secret=_required("WEBHOOK_SECRET"),
        supabase_url=_required("SUPABASE_URL").rstrip("/"),
        supabase_key=_required("SUPABASE_SERVICE_ROLE_KEY"),
        admin_ids=_parse_admin_ids(_optional("ADMIN_IDS")),
        public_base_url=_optional("PUBLIC_BASE_URL"),
        app_name=_optional("APP_NAME", "Queue Bot"),
    )
